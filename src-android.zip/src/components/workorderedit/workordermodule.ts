import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';
import { WorkordereditComponent } from './workorderedit';

@NgModule({
    declarations: [WorkordereditComponent],
    imports: [IonicModule],
    exports: [WorkordereditComponent],
    providers: []
})
export class workordereditModule { }